"""Pruebas automatizadas del módulo."""
